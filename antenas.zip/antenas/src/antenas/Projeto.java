package antenas;

public class Projeto {

	private String chave;
	//acrescentar todos os demais atributos do projeto que foram passados na fase de requisitos

	public Projeto(String chave) {
		this.chave = chave;
	}

	public String getChave() {
		return chave;
	}

	public void setChave(String chave) {
		this.chave = chave;
	}

	
	
	
	
	
}
