package antenas;

public class Professor {

}
